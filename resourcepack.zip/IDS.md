# IDs de CustomModelData (para el código Java)

Base item: `minecraft:player_head`

| Categoría | Clave | custom_model_data |
|---|---|---|
| npc | luna | 500001 |
| npc | ammy | 500002 |
| npc | mago | 500003 |
| npc | miku | 500004 |
| npc | wumpus | 500005 |
| npc | knight_gold | 500006 |
| npc | teto | 500007 |
| pet | ammy | 600001 |
| pet | grimmchild | 600002 |
| pet | warden_baby | 600003 |
| pet | miku | 600004 |
| pet | amongus_rojo | 600005 |
| pet | amongus_blanco | 600006 |
| pet | amongus_celeste | 600007 |
| pet | amongus_lima | 600008 |
| pet | amongus_naranja | 600009 |
| pet | amongus_amarillo | 600010 |
